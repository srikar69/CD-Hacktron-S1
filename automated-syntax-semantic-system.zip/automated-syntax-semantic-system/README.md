# Automated Syntax and Semantic Processing System

A Flask web app that runs lexical, syntax and semantic analysis on a small C-like language (Python + PLY).

## Run it (Windows, VS Code)
1. Install Python 3.10+ and VS Code; open this folder in VS Code and open the integrated terminal.
2. `python -m venv .venv`
3. `.\.venv\Scripts\Activate.ps1`  (if blocked: `Set-ExecutionPolicy -Scope Process Bypass`)
4. `python -m pip install -r requirements.txt`
5. `python app.py`, then open http://127.0.0.1:5000
6. Tests: `python -m pytest -v`

## Architecture
```
Browser (script.js) --POST /analyze {code}--> app.py --> compiler.analyze()
  1 lexer.py             PLY lex: tokens + illegal characters
  2 parser.py            PLY yacc: grammar -> custom AST (ast_nodes.py); stops at first syntax error
  3 semantic_analyzer.py walks the AST with symbol_table.py; only runs if the AST is trustworthy
```
Each request builds fresh lexer/parser/symbol-table objects, so nothing leaks between submissions.
Semantic analysis is skipped (status "Skipped") on lexical or syntax errors, and no AST is shown then.

## Supported language
Types `int float char void`; declarations with optional initializer; assignment; `+ - * /`; `== != < > <= >=`; unary `-`;
`if/else`, `while`, `return`, `{ blocks }`; functions with parameters; calls as statements or inside expressions;
int/float/string/char literals; `//` and `/* */` comments.

```
program -> stmt*          stmt -> declaration | func_def | assignment | if | while | return | block | call ';'
declaration -> type ID ['=' expr] ';'       func_def -> type ID '(' [type ID {',' type ID}] ')' block
assignment -> ID '=' expr ';'               expr -> binary ops | '-' expr | '(' expr ')' | literal | ID | call
```
Precedence (low to high): `== !=`, `< > <= >=`, `+ -`, `* /`, unary `-`. Dangling `else` binds to the nearest `if`.

## Type rules
Numeric = int, float, char. Arithmetic/comparison need numeric operands (arithmetic gives float if either is float, else int).
Assignments, initializers, arguments and returns allow equal types or widening (char->int, int->float). float->int is an error.
String literals exist only to demonstrate mismatches. Conditions must be numeric. Scopes: global, function, block (shadowing allowed).

## Troubleshooting
- `ModuleNotFoundError: ply/flask`: activate the venv and rerun step 4; in VS Code use Ctrl+Shift+P, "Python: Select Interpreter", pick `.venv`.
- Port 5000 busy: change `port=5000` in `app.py` (e.g. 5001).
- PLY messages in the terminal: grammar warnings are silenced; if you edit grammar docstrings in `parser.py`, keep the `rule : a | b` format and run the tests.

## Known limitations / future work
Only the first syntax error is reported (no error recovery); no `for`, arrays, pointers, `&&`/`||`, or `string` variables;
no check that non-void functions return on every path; no unused/uninitialized-variable warnings; no code generation.
