const $ = id => document.getElementById(id);
const EXAMPLES = [
`// Valid program
int count = 0;
float total;
total = 5 + 3 * 2;

int square(int n) {
    return n * n;
}

while (count < 3) {
    count = count + 1;
}
if (total >= 10) {
    int y = square(count);
} else {
    total = 0;
}`,
`// Semantic errors
int x;
int x;
y = 10;
x = "hello";
float f = 2.5;
x = f;`,
`// Syntax error (missing semicolon)
int a
a = 1;`];
let exIndex = 0, last = null;

const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const badge = s => `<span class="${s === 'Valid' ? 'ok' : s === 'Invalid' ? 'bad' : 'warn'}">${esc(s)}</span>`;

function list(id, items, fmt) {
  $(id).innerHTML = items.length ? items.map(fmt).join('') : '<li class="none">None</li>';
}

function render(r) {
  last = r;
  $('s-tokens').textContent = r.token_count;
  $('s-syntax').innerHTML = badge(r.syntax.status);
  $('s-sem').innerHTML = badge(r.semantic.status);
  $('s-err').innerHTML = `<span class="${r.error_count ? 'bad' : 'ok'}">${r.error_count}</span>`;
  $('t-tokens').innerHTML = r.tokens.map(t => `<tr><td>${esc(t.type)}</td><td>${esc(t.lexeme)}</td><td>${t.line}</td></tr>`).join('');
  $('t-sym').innerHTML = r.symbols.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.type)}</td><td>${esc(s.scope)}</td><td>${s.line}</td><td>${esc(s.status)}</td></tr>`).join('')
    || '<tr><td colspan="5" class="note">No symbols recorded.</td></tr>';
  list('e-lex', r.lexical_errors, e => `<li>Line ${e.line}: ${esc(e.message)}</li>`);
  list('e-syn', r.syntax_errors, e => `<li>Line ${e.line}: ${esc(e.message)}</li>`);
  list('e-sem', r.semantic_errors, e => `<li><b>${esc(e.category)}</b> - line ${e.line}${e.identifier ? ` (<code>${esc(e.identifier)}</code>)` : ''}: ${esc(e.message)}<small>Fix: ${esc(e.suggestion)}</small></li>`);
  $('syntax-out').innerHTML = r.syntax.status === 'Valid'
    ? '<span class="ok">Valid</span> - the program follows the grammar.'
    : r.syntax.status === 'Invalid'
      ? `<span class="bad">Invalid</span> - ${r.syntax_errors.map(e => `line ${e.line}: ${esc(e.message)}`).join('<br>')}`
      : '<span class="warn">Unreliable</span> - fix the illegal characters first.';
  showAst();
}

function showAst() {
  if (!last) return;
  $('ast').textContent = !last.ast ? 'No AST: parsing did not succeed.'
    : $('asjson').checked ? JSON.stringify(last.ast, null, 2) : last.ast_text;
}

async function analyze() {
  const code = $('code').value;
  $('msg').textContent = '';
  if (!code.trim()) { $('msg').textContent = 'Enter some source code first.'; return; }
  $('analyze').disabled = true;
  try {
    const res = await fetch('/analyze', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({code})});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed.');
    render(data);
  } catch (e) {
    $('msg').textContent = e.message || 'Could not reach the server.';
  } finally { $('analyze').disabled = false; }
}

$('analyze').onclick = analyze;
$('example').onclick = () => { $('code').value = EXAMPLES[exIndex]; exIndex = (exIndex + 1) % EXAMPLES.length; analyze(); };
$('clear').onclick = () => { $('code').value = ''; $('msg').textContent = ''; $('code').focus(); };
$('asjson').onchange = showAst;
$('code').addEventListener('keydown', e => { if (e.ctrlKey && e.key === 'Enter') analyze(); });
