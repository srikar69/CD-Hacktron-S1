from flask import Flask, jsonify, render_template, request
from compiler import analyze

app = Flask(__name__)
MAX_CHARS = 20000


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/analyze")
def analyze_route():
    data = request.get_json(silent=True)
    if not isinstance(data, dict) or not isinstance(data.get("code"), str):
        return jsonify(error="Request must be JSON like {\"code\": \"...\"}."), 400
    code = data["code"]
    if not code.strip():
        return jsonify(error="Source code is empty. Type or load a program first."), 400
    if len(code) > MAX_CHARS:
        return jsonify(error=f"Source code is too long (max {MAX_CHARS} characters)."), 413
    try:
        return jsonify(analyze(code))
    except Exception:  # log details server-side only
        app.logger.exception("Analysis failed")
        return jsonify(error="Unexpected error while analyzing the code."), 500


if __name__ == "__main__":
    app.run(debug=False, port=5000)
