"""Phase 3 - Semantic analysis: walks the AST using the symbol table.

Type rules
  * numeric types: int, float, char (char is promoted to int in arithmetic)
  * arithmetic (+ - * /): both operands numeric; result float if either is float, else int
  * comparison (== != < > <= >=): both operands numeric; result int
  * assignment / initializer / argument / return: same type or widening
    (char->int, int->float, char->float). float->int is rejected (loses precision).
  * if/while conditions must be numeric; void variables are illegal.
"""
from .symbol_table import SymbolTable

NUMERIC = {"int", "float", "char"}


def compatible(target, value):
    return target == value or (target, value) in {("int", "char"), ("float", "int"), ("float", "char")}


class SemanticAnalyzer:
    def __init__(self):
        self.table, self.errors, self.fn = SymbolTable(), [], None

    def error(self, category, line, ident, message, suggestion=""):
        self.errors.append({"category": category, "line": line, "identifier": ident,
                            "message": message, "suggestion": suggestion})

    def run(self, ast):
        self.visit(ast)
        return self.errors

    def visit(self, node):
        return getattr(self, "v_" + node.kind)(node)

    # ---- statements ----
    def v_Program(self, n):
        for s in n.body:
            self.visit(s)

    def v_Block(self, n):
        self.table.enter()
        for s in n.body:
            self.visit(s)
        self.table.exit()

    def v_VarDecl(self, n):
        init_t = self.visit(n.init) if n.init else None
        if n.var_type == "void":
            self.error("Invalid Declaration", n.line, n.name, f"Variable '{n.name}' cannot have type void.",
                       "Use int, float or char.")
            return
        old = self.table.declare(n.name, n.var_type, n.line, "initialized" if n.init else "declared")
        if old:
            self.error("Duplicate Declaration", n.line, n.name,
                       f"'{n.name}' is already declared in {old.scope} scope (line {old.line}).",
                       f"Remove this declaration or rename it, e.g. '{n.name}2'.")
        if init_t and init_t != "error" and not compatible(n.var_type, init_t):
            self.mismatch(n.line, n.name, n.var_type, init_t)

    def mismatch(self, line, name, target, value):
        hint = (f"Declare '{name}' as float, or use an int value." if (target, value) == ("int", "float")
                else f"Use a {target} value, or change the declaration of '{name}'.")
        self.error("Type Mismatch", line, name, f"Cannot assign {value} value to {target} variable '{name}'.", hint)

    def v_FunctionDecl(self, n):
        old = self.table.declare(n.name, n.return_type, n.line, "function", "function",
                                 [p.var_type for p in n.params])
        if old:
            self.error("Duplicate Declaration", n.line, n.name,
                       f"'{n.name}' is already declared in {old.scope} scope (line {old.line}).", "Rename the function.")
        self.table.enter(f"function {n.name}")
        for p in n.params:
            if p.var_type == "void" or self.table.declare(p.name, p.var_type, p.line, "parameter"):
                self.error("Invalid Parameter", p.line, p.name, f"Parameter '{p.name}' is invalid or duplicated.",
                           "Use a unique name and a non-void type.")
        saved, self.fn = self.fn, n
        for s in n.body.body:  # body shares the function scope so params can't be redeclared
            self.visit(s)
        self.fn = saved
        self.table.exit()

    def v_Assignment(self, n):
        name = n.target.name
        value_t = self.visit(n.value)
        sym = self.table.lookup(name)
        if sym is None:
            return self.undeclared(n.line, name)
        if sym.kind == "function":
            return self.error("Invalid Assignment", n.line, name, f"'{name}' is a function and cannot be assigned to.",
                              "Assign to a variable instead.")
        if value_t == "error":
            return
        if compatible(sym.type, value_t):
            if sym.status == "declared":
                sym.status = "initialized"
        else:
            self.mismatch(n.line, name, sym.type, value_t)

    def undeclared(self, line, name):
        self.error("Undeclared Variable", line, name, f"'{name}' is used before it is declared.",
                   f"Declare it first, e.g. 'int {name};'.")
        return "error"

    def condition(self, expr, word):
        t = self.visit(expr)
        if t != "error" and t not in NUMERIC:
            self.error("Invalid Condition", expr.line, None, f"The {word} condition must be numeric, found {t}.",
                       "Use a comparison such as x < 10.")

    def v_If(self, n):
        self.condition(n.cond, "if")
        self.visit(n.then_branch)
        if n.else_branch:
            self.visit(n.else_branch)

    def v_While(self, n):
        self.condition(n.cond, "while")
        self.visit(n.body)

    def v_Return(self, n):
        t = self.visit(n.value) if n.value else "void"
        if self.fn is None:
            return self.error("Invalid Return", n.line, None, "'return' used outside a function.", "Move it inside a function.")
        want = self.fn.return_type
        if t != "error" and not compatible(want, t):
            self.error("Invalid Return Type", n.line, self.fn.name,
                       f"Function '{self.fn.name}' returns {want} but this returns {t}.",
                       "Return a value of the declared type." if want != "void" else "Remove the return value.")

    def v_ExprStmt(self, n):
        self.visit(n.expr)

    # ---- expressions: each returns a type string ('error' stops cascades) ----
    def v_Number(self, n):
        return n.num_type

    def v_String(self, n):
        return "string"

    def v_Char(self, n):
        return "char"

    def v_Identifier(self, n):
        sym = self.table.lookup(n.name)
        if sym is None:
            return self.undeclared(n.line, n.name)
        if sym.kind == "function":
            self.error("Invalid Use", n.line, n.name, f"'{n.name}' is a function, not a variable.", f"Call it: {n.name}(...)")
            return "error"
        return sym.type

    def v_UnaryOp(self, n):
        t = self.visit(n.operand)
        if t != "error" and t not in NUMERIC:
            self.error("Invalid Operation", n.line, "-", f"Unary '-' cannot be applied to {t}.", "Use a numeric operand.")
            return "error"
        return "int" if t == "char" else t

    def v_BinaryOp(self, n):
        lt, rt = self.visit(n.left), self.visit(n.right)
        if "error" in (lt, rt):
            return "error"
        if lt not in NUMERIC or rt not in NUMERIC:
            self.error("Invalid Operation", n.line, n.op, f"Operator '{n.op}' cannot be applied to {lt} and {rt}.",
                       "Use numeric (int, float, char) operands.")
            return "error"
        if n.op == "/" and n.right.kind == "Number" and n.right.value == 0:
            self.error("Division By Zero", n.line, "/", "Division by constant zero.", "Use a non-zero divisor.")
        if n.op in ("==", "!=", "<", ">", "<=", ">="):
            return "int"
        return "float" if "float" in (lt, rt) else "int"

    def v_Call(self, n):
        arg_types = [self.visit(a) for a in n.args]
        sym = self.table.lookup(n.name)
        if sym is None or sym.kind != "function":
            self.error("Undeclared Function" if sym is None else "Invalid Call", n.line, n.name,
                       f"'{n.name}' is not a declared function.", "Define the function before calling it.")
            return "error"
        if len(arg_types) != len(sym.params):
            self.error("Argument Mismatch", n.line, n.name,
                       f"'{n.name}' expects {len(sym.params)} argument(s) but got {len(arg_types)}.",
                       "Match the number of parameters.")
        else:
            for i, (want, got) in enumerate(zip(sym.params, arg_types), 1):
                if got != "error" and not compatible(want, got):
                    self.error("Argument Mismatch", n.line, n.name,
                               f"Argument {i} of '{n.name}' should be {want} but is {got}.", f"Pass a {want} value.")
        return sym.type
