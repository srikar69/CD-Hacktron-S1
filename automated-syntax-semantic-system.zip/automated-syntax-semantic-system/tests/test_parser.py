from compiler.parser import parse_source


def test_valid_program():
    ast, err = parse_source("int x;\nx = 10;")
    assert err is None and len(ast.body) == 2


def test_missing_semicolon_reports_line():
    ast, err = parse_source("int x\nx = 10;")
    assert ast is None and err.line == 1


def test_precedence():
    ast, _ = parse_source("int x;\nx = 5 + 3 * 2;")
    value = ast.body[1].value
    assert value.op == "+" and value.right.op == "*"


def test_unexpected_end():
    ast, err = parse_source("while (1) {")
    assert ast is None and "end of input" in err.message


def test_malformed_expression():
    assert parse_source("int x;\nx = 5 + ;")[1] is not None
