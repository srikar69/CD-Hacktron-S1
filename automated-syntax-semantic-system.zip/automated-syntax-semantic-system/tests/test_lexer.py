from compiler.lexer import tokenize


def test_tokens_and_lines():
    toks, errs = tokenize("int total = 10;\nfloat y = 2.5;")
    assert not errs
    assert [(t["type"], t["lexeme"], t["line"]) for t in toks[:5]] == [
        ("KEYWORD", "int", 1), ("ID", "total", 1), ("ASSIGN", "=", 1), ("NUMBER", "10", 1), ("SEMI", ";", 1)]
    assert toks[-2]["lexeme"] == "2.5" and toks[-2]["line"] == 2


def test_illegal_character():
    _, errs = tokenize("int x;\nx = 10 @ 2;")
    assert errs[0]["character"] == "@" and errs[0]["line"] == 2


def test_comments_keep_line_numbers():
    toks, _ = tokenize("// hi\n/* a\nb */ int x;")
    assert toks[0]["lexeme"] == "int" and toks[0]["line"] == 3


def test_two_char_operators():
    toks, _ = tokenize("a <= b == c != d")
    assert [t["type"] for t in toks if t["type"] != "ID"] == ["LE", "EQ", "NE"]
