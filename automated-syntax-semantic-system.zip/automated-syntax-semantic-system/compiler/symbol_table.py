"""Scoped symbol table: a stack of scopes plus a flat list for display."""


class Symbol:
    def __init__(self, name, type_, scope, line, status, kind="variable", params=None):
        self.name, self.type, self.scope, self.line = name, type_, scope, line
        self.status, self.kind, self.params = status, kind, params or []

    def to_dict(self):
        return {"name": self.name, "type": self.type, "scope": self.scope,
                "line": self.line, "status": self.status}


class SymbolTable:
    def __init__(self):
        self.scopes, self.names, self.all, self._blocks = [{}], ["global"], [], 0

    def enter(self, name=None):
        self._blocks += 1
        self.names.append(name or f"block {self._blocks}")
        self.scopes.append({})

    def exit(self):
        self.scopes.pop()
        self.names.pop()

    @property
    def scope_name(self):
        return self.names[-1]

    def declare(self, name, type_, line, status, kind="variable", params=None):
        """Return None on success, or the existing Symbol if duplicated in this scope."""
        if name in self.scopes[-1]:
            return self.scopes[-1][name]
        sym = Symbol(name, type_, self.scope_name, line, status, kind, params)
        self.scopes[-1][name] = sym
        self.all.append(sym)
        return None

    def lookup(self, name):
        for scope in reversed(self.scopes):  # innermost first -> shadowing works
            if name in scope:
                return scope[name]
        return None
