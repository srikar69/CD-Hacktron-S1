"""Runs the three phases separately and assembles the JSON result."""
from .lexer import tokenize
from .parser import parse_source
from .semantic_analyzer import SemanticAnalyzer
from .ast_nodes import tree_text


def analyze(code):
    tokens, lex_errors = tokenize(code)
    ast, syn = parse_source(code)

    syntax_errors = []
    if syn:
        msg = syn.message
        if lex_errors:
            msg += " (Illegal characters were skipped by the lexer and may be the cause.)"
        syntax_errors.append({"line": syn.line, "message": msg})

    ast_dict = ast_text = None
    symbols, sem_errors = [], []
    if ast is not None and not lex_errors:  # semantic phase needs a trustworthy AST
        analyzer = SemanticAnalyzer()
        sem_errors = analyzer.run(ast)
        symbols = [s.to_dict() for s in analyzer.table.all]
        ast_dict, ast_text = ast.to_dict(), tree_text(ast)
        sem_status = "Invalid" if sem_errors else "Valid"
    else:
        sem_status = "Skipped"

    syntax_status = "Invalid" if syntax_errors else ("Unreliable" if lex_errors else "Valid")
    total = len(lex_errors) + len(syntax_errors) + len(sem_errors)
    return {
        "tokens": tokens, "token_count": len(tokens),
        "lexical_errors": lex_errors,
        "syntax": {"status": syntax_status}, "syntax_errors": syntax_errors,
        "ast": ast_dict, "ast_text": ast_text,
        "symbols": symbols,
        "semantic": {"status": sem_status}, "semantic_errors": sem_errors,
        "error_count": total, "overall": "Success" if total == 0 else "Errors found",
    }
