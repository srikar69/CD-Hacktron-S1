"""Phase 2 - Syntax analysis (PLY yacc). Builds the AST from grammar productions.

Grammar (also in README):
  program     -> stmt*
  stmt        -> declaration | func_def | assignment | if | while | return | block | call ';'
  declaration -> type ID ['=' expr] ';'
  func_def    -> type ID '(' [type ID {',' type ID}] ')' block
"""
import ply.yacc as yacc
from .lexer import CLexer
from .ast_nodes import Node


class SyntaxErr(Exception):
    def __init__(self, line, message):
        super().__init__(message)
        self.line, self.message = line, message


class _Tracker:
    """Wraps the lexer so we remember the last two tokens (for better messages)."""

    def __init__(self):
        self.lx = CLexer().build()
        self.last = self.prev = None

    def input(self, data):
        self.lx.lexer.input(data)

    def token(self):
        t = self.lx.lexer.token()
        if t is not None:
            self.prev, self.last = self.last, t
        return t


class CParser:
    tokens = CLexer.tokens
    start = "program"
    precedence = (
        ("nonassoc", "IFX"), ("nonassoc", "ELSE"),
        ("left", "EQ", "NE"), ("left", "LT", "GT", "LE", "GE"),
        ("left", "PLUS", "MINUS"), ("left", "TIMES", "DIVIDE"),
        ("right", "UMINUS"),
    )

    def __init__(self):
        self.tracker = None

    # ---- program / statements ----
    def p_program(self, p):
        "program : stmt_list"
        p[0] = Node("Program", 1, body=p[1])

    def p_stmt_list(self, p):
        """stmt_list : stmt_list stmt
                     | empty"""
        p[0] = p[1] + [p[2]] if len(p) == 3 else []

    def p_empty(self, p):
        "empty :"

    def p_stmt(self, p):
        """stmt : declaration
                | func_def
                | assignment
                | if_stmt
                | while_stmt
                | return_stmt
                | block
                | call SEMI"""
        p[0] = p[1] if len(p) == 2 else Node("ExprStmt", p[1].line, expr=p[1])

    def p_type(self, p):
        """type : INT
                | FLOAT
                | CHAR
                | VOID"""
        p[0] = p[1]

    def p_declaration(self, p):
        """declaration : type ID SEMI
                       | type ID ASSIGN expr SEMI"""
        p[0] = Node("VarDecl", p.lineno(2), var_type=p[1], name=p[2], init=p[4] if len(p) == 6 else None)

    def p_func_def(self, p):
        "func_def : type ID LPAREN params RPAREN block"
        p[0] = Node("FunctionDecl", p.lineno(2), return_type=p[1], name=p[2], params=p[4], body=p[6])

    def p_params(self, p):
        """params : param_list
                  | empty"""
        p[0] = p[1] or []

    def p_param_list(self, p):
        """param_list : param_list COMMA param
                      | param"""
        p[0] = p[1] + [p[3]] if len(p) == 4 else [p[1]]

    def p_param(self, p):
        "param : type ID"
        p[0] = Node("Param", p.lineno(2), var_type=p[1], name=p[2])

    def p_assignment(self, p):
        "assignment : ID ASSIGN expr SEMI"
        p[0] = Node("Assignment", p.lineno(1), target=Node("Identifier", p.lineno(1), name=p[1]), value=p[3])

    def p_if(self, p):
        """if_stmt : IF LPAREN expr RPAREN stmt %prec IFX
                   | IF LPAREN expr RPAREN stmt ELSE stmt"""
        p[0] = Node("If", p.lineno(1), cond=p[3], then_branch=p[5], else_branch=p[7] if len(p) == 8 else None)

    def p_while(self, p):
        "while_stmt : WHILE LPAREN expr RPAREN stmt"
        p[0] = Node("While", p.lineno(1), cond=p[3], body=p[5])

    def p_return(self, p):
        """return_stmt : RETURN expr SEMI
                       | RETURN SEMI"""
        p[0] = Node("Return", p.lineno(1), value=p[2] if len(p) == 4 else None)

    def p_block(self, p):
        "block : LBRACE stmt_list RBRACE"
        p[0] = Node("Block", p.lineno(1), body=p[2])

    # ---- expressions ----
    def p_expr_binop(self, p):
        """expr : expr PLUS expr
                | expr MINUS expr
                | expr TIMES expr
                | expr DIVIDE expr
                | expr EQ expr
                | expr NE expr
                | expr LT expr
                | expr GT expr
                | expr LE expr
                | expr GE expr"""
        p[0] = Node("BinaryOp", p.lineno(2), op=p[2], left=p[1], right=p[3])

    def p_expr_unary(self, p):
        "expr : MINUS expr %prec UMINUS"
        p[0] = Node("UnaryOp", p.lineno(1), op="-", operand=p[2])

    def p_expr_group(self, p):
        "expr : LPAREN expr RPAREN"
        p[0] = p[2]

    def p_expr_int(self, p):
        "expr : INT_NUM"
        p[0] = Node("Number", p.lineno(1), value=int(p[1]), num_type="int")

    def p_expr_float(self, p):
        "expr : FLOAT_NUM"
        p[0] = Node("Number", p.lineno(1), value=float(p[1]), num_type="float")

    def p_expr_string(self, p):
        "expr : STRING"
        p[0] = Node("String", p.lineno(1), value=p[1][1:-1])

    def p_expr_char(self, p):
        "expr : CHAR_LIT"
        p[0] = Node("Char", p.lineno(1), value=p[1][1:-1])

    def p_expr_id(self, p):
        "expr : ID"
        p[0] = Node("Identifier", p.lineno(1), name=p[1])

    def p_expr_call(self, p):
        "expr : call"
        p[0] = p[1]

    def p_call(self, p):
        "call : ID LPAREN args RPAREN"
        p[0] = Node("Call", p.lineno(1), name=p[1], args=p[3])

    def p_args(self, p):
        """args : arg_list
                | empty"""
        p[0] = p[1] or []

    def p_arg_list(self, p):
        """arg_list : arg_list COMMA expr
                    | expr"""
        p[0] = p[1] + [p[3]] if len(p) == 4 else [p[1]]

    # ---- error handling: stop at the first error, never report false success ----
    def p_error(self, p):
        t = self.tracker
        if p is None:
            raise SyntaxErr(t.last.lineno if t.last else 1,
                            "Unexpected end of input; a ';' or closing '}' may be missing.")
        prev = t.prev
        if prev is not None and prev.lineno < p.lineno and prev.type not in ("SEMI", "LBRACE", "RBRACE"):
            raise SyntaxErr(prev.lineno, f"Possible missing ';' after '{prev.value}' "
                                         f"(unexpected '{p.value}' on line {p.lineno}).")
        raise SyntaxErr(p.lineno, f"Unexpected token '{p.value}'.")

    def parse(self, code):
        self.tracker = _Tracker()
        parser = yacc.yacc(module=self, write_tables=False, debug=False, errorlog=yacc.NullLogger())
        return parser.parse(code, lexer=self.tracker)


def parse_source(code):
    """Return (ast, syntax_error). Exactly one of them is None."""
    try:
        ast = CParser().parse(code)
        return (ast, None) if ast is not None else (None, SyntaxErr(1, "Parsing failed."))
    except SyntaxErr as e:
        return None, e
