"""Phase 1 - Lexical analysis (PLY lex)."""
import ply.lex as lex

RESERVED = {
    "int": "INT", "float": "FLOAT", "char": "CHAR", "void": "VOID",
    "if": "IF", "else": "ELSE", "while": "WHILE", "return": "RETURN",
}


class CLexer:
    """One instance per request, so no state leaks between submissions."""

    tokens = [
        "ID", "FLOAT_NUM", "INT_NUM", "STRING", "CHAR_LIT",
        "PLUS", "MINUS", "TIMES", "DIVIDE", "ASSIGN",
        "EQ", "NE", "LE", "GE", "LT", "GT",
        "SEMI", "COMMA", "LPAREN", "RPAREN", "LBRACE", "RBRACE",
    ] + list(RESERVED.values())

    # Simple tokens (PLY tries longer regexes first, so '==' beats '=')
    t_PLUS, t_MINUS, t_TIMES, t_DIVIDE = r"\+", r"-", r"\*", r"/"
    t_EQ, t_NE, t_LE, t_GE, t_LT, t_GT, t_ASSIGN = r"==", r"!=", r"<=", r">=", r"<", r">", r"="
    t_SEMI, t_COMMA = r";", r","
    t_LPAREN, t_RPAREN, t_LBRACE, t_RBRACE = r"\(", r"\)", r"\{", r"\}"
    t_ignore = " \t\r"

    def t_COMMENT(self, t):
        r"//[^\n]*|/\*(.|\n)*?\*/"
        t.lexer.lineno += t.value.count("\n")  # discarded, but keep line count right

    def t_STRING(self, t):
        r'"[^"\n]*"'
        return t

    def t_CHAR_LIT(self, t):
        r"'[^'\n]'"
        return t

    def t_FLOAT_NUM(self, t):
        r"\d+\.\d+"
        return t

    def t_INT_NUM(self, t):
        r"\d+"
        return t

    def t_ID(self, t):
        r"[A-Za-z_][A-Za-z_0-9]*"
        t.type = RESERVED.get(t.value, "ID")  # keywords match the ID pattern, then get retyped
        return t

    def t_newline(self, t):
        r"\n+"
        t.lexer.lineno += len(t.value)

    def t_error(self, t):
        self.errors.append({"line": t.lineno, "character": t.value[0],
                            "message": f"Illegal character '{t.value[0]}'"})
        t.lexer.skip(1)

    def build(self):
        self.errors = []
        self.lexer = lex.lex(module=self)
        return self


def display_type(tok_type):
    if tok_type in RESERVED.values():
        return "KEYWORD"
    return "NUMBER" if tok_type in ("INT_NUM", "FLOAT_NUM") else tok_type


def tokenize(code):
    """Return (token_rows, lexical_errors)."""
    lx = CLexer().build()
    lx.lexer.input(code)
    rows = [{"type": display_type(t.type), "lexeme": t.value, "line": t.lineno} for t in lx.lexer]
    return rows, lx.errors
