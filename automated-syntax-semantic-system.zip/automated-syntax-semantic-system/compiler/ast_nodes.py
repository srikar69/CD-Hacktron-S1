"""Custom AST: one generic Node class plus helpers to print it."""


class Node:
    def __init__(self, kind, line=None, **fields):
        self.kind, self.line, self.fields = kind, line, fields
        self.__dict__.update(fields)  # allows node.name, node.left, ...

    def to_dict(self):
        d = {"node": self.kind, "line": self.line}
        d.update({k: _conv(v) for k, v in self.fields.items()})
        return d


def _conv(v):
    if isinstance(v, Node):
        return v.to_dict()
    return [_conv(i) for i in v] if isinstance(v, list) else v


def tree_text(root):
    """Readable indented tree of the AST."""
    lines = []

    def label(n):
        attrs = ", ".join(f"{k}={v!r}" for k, v in n.fields.items()
                          if not isinstance(v, (Node, list)) and v is not None)
        return n.kind + (f" [{attrs}]" if attrs else "") + (f"  (line {n.line})" if n.line else "")

    def walk(n, prefix, tag, last, is_root=False):
        lines.append(prefix + ("" if is_root else "└── " if last else "├── ") + tag + label(n))
        ext = "" if is_root else ("    " if last else "│   ")
        kids = []
        for k, v in n.fields.items():
            if isinstance(v, Node):
                kids.append((k + ": ", v))
            elif isinstance(v, list):
                kids += [(f"{k}[{i}]: ", c) for i, c in enumerate(v) if isinstance(c, Node)]
        for i, (t, c) in enumerate(kids):
            walk(c, prefix + ext, t, i == len(kids) - 1)

    walk(root, "", "", True, True)
    return "\n".join(lines)
