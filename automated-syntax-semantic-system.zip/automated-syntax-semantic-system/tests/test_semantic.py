from compiler import analyze


def cats(code):
    return [e["category"] for e in analyze(code)["semantic_errors"]]


def test_valid():
    r = analyze("int x;\nx = 10;")
    assert r["overall"] == "Success" and r["semantic"]["status"] == "Valid"


def test_undeclared():
    assert cats("x = 10;") == ["Undeclared Variable"]


def test_duplicate_and_shadowing():
    assert cats("int x;\nint x;") == ["Duplicate Declaration"]
    assert cats("int x;\n{ int x; x = 1; }") == []


def test_type_mismatch():
    assert cats('int x;\nx = "hello";') == ["Type Mismatch"]
    assert cats("int x;\nx = 2.5;") == ["Type Mismatch"]
    assert cats("float f;\nf = 2;") == []


def test_semantics_skipped_on_syntax_error():
    r = analyze("int x\nx = 10;")
    assert r["semantic"]["status"] == "Skipped" and r["ast"] is None and r["symbols"] == []


def test_no_state_leak_between_requests():
    analyze("int leak;")
    assert cats("leak = 1;") == ["Undeclared Variable"]


def test_functions():
    assert cats("int f(int a) { return a; }\nint y = f(1);") == []
    assert cats("int f(int a) { return a; }\nint y = f();") == ["Argument Mismatch"]
    assert cats('int f() { return "s"; }') == ["Invalid Return Type"]
    assert cats("return 1;") == ["Invalid Return"]


def test_nested_scope_out_of_scope_use():
    assert cats("{ int a; }\na = 1;") == ["Undeclared Variable"]
