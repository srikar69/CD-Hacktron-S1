from app import app


def test_api_cases():
    c = app.test_client()
    assert c.post("/analyze", json={"code": ""}).status_code == 400
    assert c.post("/analyze", data="nope").status_code == 400
    r = c.post("/analyze", json={"code": "int x;\nx = 10;"})
    assert r.status_code == 200 and r.get_json()["overall"] == "Success"
    assert c.get("/").status_code == 200
